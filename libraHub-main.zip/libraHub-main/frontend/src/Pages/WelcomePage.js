import React from "react";
import FrontCard from "../components/FrontCard";

const WelcomePage = () => {
  return <FrontCard />;
};

export default WelcomePage;
